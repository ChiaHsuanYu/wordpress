<?php get_header(); ?>

<div class="content">
	
	<?php get_template_part('inc/page-title'); ?>

</div><!--/.content-->

<?php get_sidebar(); ?>

<?php get_footer(); ?>