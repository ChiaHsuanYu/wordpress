import "./control.scss";

wp.customize.controlConstructor['kirki-radio']           = wp.customize.kirkiDynamicControl.extend( {} );
wp.customize.controlConstructor['kirki-radio-buttonset'] = wp.customize.kirkiDynamicControl.extend( {} );
wp.customize.controlConstructor['kirki-radio-image']     = wp.customize.kirkiDynamicControl.extend( {} );
